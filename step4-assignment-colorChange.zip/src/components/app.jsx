import { Component } from "react";
import axios from "axios"
 
class App extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=1")
        .then(res=> this.setState({users:res.data.data})) //first data is data and second data is data from url
        .catch(err=> console.log("Error : ",err))

    }
    render(){
        console.log("App Component's render was called")
       return <div>
                   <h1>Ajax | API Cycle</h1>
                   <hr />
                   <ol>
                    {this.state.users.map(val =><li key={val.id} style={{backgroundColor: val.id%2===0? "green":"yellow"}}><img width="100px" src={val.avatar}/>{val.first_name+" "+val.last_name}</li>)}
                   </ol>
               </div>
    }
}
 
export default App;