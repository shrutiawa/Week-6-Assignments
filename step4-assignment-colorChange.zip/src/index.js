import React from "react" //React is a dafault export
import App from "./components/app" //React is a dafault export
import {createRoot } from "react-dom/client"  //createRoot is a named export


createRoot(document.getElementById("root")).render(<div><App/></div>)