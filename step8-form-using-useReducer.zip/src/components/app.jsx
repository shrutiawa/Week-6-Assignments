import { useReducer, useState } from "react";
let App = () => {
    let reducerFun = (state, action) => {
        console.log(action)
        switch (action.type) {
            case "SET_VALUE": return { ...state, [action.field]: action.value }
            case "SUBMIT": return { ...state, submitted: true }
            default: return state
        }
    };
    let [store, dispatch] = useReducer(reducerFun, {
        name: "",
        email: " ",
        age: 18,
        phone: 0,
        submitted: false
    });
    let userDetailsChangeHandler = (evt) => {
        
        let { id, value } = evt.target;
        dispatch({ type: "SET_VALUE", field: id, value })
    }
    let submitChange = () => {
        console.log("Submit")
        dispatch({ type: "SUBMIT" })
    }
    return <div className="container">
        <h1>Forms in React</h1>
        <div className="mb-3">

            <label htmlFor="name" className="form-label">User Name</label>
            <input onChange={userDetailsChangeHandler} value={store.name} className="form-control" id="name" placeholder="User Name" />
        </div>
        <div className="mb-3">
            <label htmlFor="email" className="form-label">User eMail</label>
            <input onChange={userDetailsChangeHandler} value={store.email} type="email" className="form-control" id="email" placeholder="User eMail" />
        </div>
        <div className="mb-3">
            <label htmlFor="age" className="form-label">User Age</label>
            <input onChange={userDetailsChangeHandler} value={store.age} type="number" className="form-control" id="age" placeholder="User Age" />
        </div>
        <div className="mb-3">
            <label htmlFor="phone" className="form-label">User Phone</label>
            <input onChange={userDetailsChangeHandler} value={store.phone} className="form-control" id="phone" placeholder="Your Phone" />
        </div>
        <div className="mb-3">
            <button className="btn btn-primary" onClick={submitChange}>Register</button>
        </div>
        {store.submitted && (
            <ul>
                <li>User Name: {store.name}</li>
                <li>User eMail: {store.email}</li>
                <li>User Age: {store.age}</li>
                <li>User Phone: {store.phone}</li>
            </ul>
        )}
    </div>

}
export default App