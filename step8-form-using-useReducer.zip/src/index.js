import React from "react" //React is a dafault export
import App from "./components/app" 
import {createRoot } from "react-dom/client"  //createRoot is a named export


createRoot(document.getElementById("root")).render(<App/>)